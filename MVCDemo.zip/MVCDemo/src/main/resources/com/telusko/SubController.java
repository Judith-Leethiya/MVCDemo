package com.telusko;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class SubController {

	@RequestMapping("/sub")
	public void sub()
	{
		System.out.println("i am here");
	}
}
